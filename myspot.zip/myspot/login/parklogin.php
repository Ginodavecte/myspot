<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"/>
<link rel="stylesheet" type="text/css" href="../myspot-parking-master/myspotstylesheet.css">
<link rel="icon" type="image/png" href="../myspot-parking-master/favicon.ico">
</head>
<body>
<div class="container-fluid">
<p>Welcome to the login page</p>

</div> <!--end of "main" div-->
</body>
</html>