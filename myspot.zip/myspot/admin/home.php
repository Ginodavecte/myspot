<?php include ("../includes/database.php");?>
<?php include ("../login/session.php");?>
<head>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../myspot-parking-master/myspotstylesheet.css">
    <script src="../jquery-3.2.0.min.js"></script>

</head>

<body>
<div>
    <ul>
        <li><a href="../germain/BusinessSpots.php">Business Page</a></li>
        <li><a href="../germain/ProfilePage.php">Parkeelplaats Reserveren</a> </li>
        <li><a href="add_user.php">Voeg useraccount toe</a></li>
        <li><a href="alter_user.php">Wijzig user account</a></li>
        <li><a href="pre_delete_user.php">Verwijder useraccount</a> </li><br>
        <li><a href="../index.html">Terug naar Welkomspagina</a> </li>
        <li><a href="../login/logout.php">Log-out</a></li>
    </ul>

</div>
</body>
