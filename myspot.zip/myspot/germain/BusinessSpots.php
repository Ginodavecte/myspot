<?php include("../includes/database.php"); ?>
<?php include ("../login/session.php");?>
<head>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../myspot-parking-master/myspotstylesheet.css">
    <script src="../jquery-3.2.0.min.js"></script>

</head>
<?php

$ownerid=4;
$location ="Groningen";
$availableSpots = "SELECT AvailableSpots FROM BusinessSpots WHERE Ownerid = '$ownerid' AND Location = '$location';";
$result  = mysqli_query($connection, $availableSpots);
$subject = mysqli_fetch_assoc($result);
$allowedUsers =   "SELECT COUNT(*) as total FROM CodeGorillaUsers; ";
$result2  = mysqli_query($connection, $allowedUsers);
$subject2 = mysqli_fetch_assoc($result2);
$currentUsers ="SELECT CurrentUsers FROM BusinessSpots WHERE Ownerid = '$ownerid' AND Location = '$location';";
$result3  = mysqli_query($connection, $currentUsers);
$subject3 = mysqli_fetch_assoc($result3);
$points =10;

?>

    <form action="" method="post" >
        <table>


            <tr><td>Available Spots</td><td> <?php echo $subject['AvailableSpots']; ?></td><td><button id="share">Share</button></td></tr>
            <tr><td>Current Users</td><td> <?php echo $subject3['CurrentUsers']; ?></td></tr>
            <tr><td>Allowed Users</td><td> <?php echo $subject2['total']; ?></td></tr>
            <tr><td>Points</td><td> <?php echo $points; ?></td></tr>
        </table>


    </form>
